For Tasks 1-9 Simplay open the QAR file and compile for verification.
Then go to Tools > Netlist Viewers > RTL Viewer … for verification to see the circuit design and visually confirm.

The rest are documented in the PDF, step by step.

-Ismail