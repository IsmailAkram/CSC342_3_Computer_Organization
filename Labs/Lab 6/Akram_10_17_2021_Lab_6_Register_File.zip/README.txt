Open Quartus and load up Akram_10_15_2021_Lab_6_Register_File (QPF file)

Make sure the following are in the same directory within the project (Project > add/remove files in project)

Akram_Register_N_VHDL.vhd
Akram_9_19_2021_N_Bit_Add_Sub_Flags.vhd
Akram_10_15_2021_Lab_6_Register_File.mif -- this is important!

These are our components.

Run Compilation and verify that it works (it does).

Then go to ModelSim and open the project in there (make sure component files and .mif is in the directory too),
Run waveform simulations and force in Instruction Register values, CLK at 100ps (rising) and wren at 75ps (rising) and test.

